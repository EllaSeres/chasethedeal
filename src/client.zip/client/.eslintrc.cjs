module.exports = {
    'env': {
	'node': false,
        'browser': true
    },
    'extends': '../../.eslintrc.cjs',
};
